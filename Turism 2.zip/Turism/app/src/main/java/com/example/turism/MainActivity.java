package com.example.turism;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity implements View.OnClickListener {

    Button hoteles,museos,restaurantes,mapa,miagenda,gusto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        crea_acciones();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.hotel: Intent i1 = new Intent(MainActivity.this,MyActivity.class); startActivity(i1); break;
            case R.id.museo: Intent i2 = new Intent(MainActivity.this,MyActivityM.class); startActivity(i2); break;
            case R.id.restaurant: Intent i3 = new Intent(MainActivity.this,MyActivityR.class); startActivity(i3); break;
            case R.id.mapa: Intent i4 = new Intent(MainActivity.this,MapsActivity.class); startActivity(i4); break;
            case R.id.agenda: Intent i5 = new Intent(MainActivity.this,MyActivityAG.class); startActivity(i5); break;
            case R.id.gustos: Intent i6 = new Intent(MainActivity.this,MyActivityG.class); startActivity(i6); break;

        }

    }

    public void crea_acciones(){
        hoteles = (Button)findViewById(R.id.hotel);
        museos = (Button)findViewById(R.id.museo);
        restaurantes = (Button)findViewById(R.id.restaurant);
        mapa = (Button)findViewById(R.id.mapa);
        miagenda = (Button)findViewById(R.id.agenda);
        gusto =(Button)findViewById(R.id.gustos);
        hoteles.setOnClickListener(this);
        museos.setOnClickListener(this);
        restaurantes.setOnClickListener(this);
        mapa.setOnClickListener(this);
        miagenda.setOnClickListener(this);
        gusto.setOnClickListener(this);

    }

    //mi tabla
}
