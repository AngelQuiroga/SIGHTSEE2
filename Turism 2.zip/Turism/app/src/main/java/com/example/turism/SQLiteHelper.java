package com.example.turism;

/**
 * Created by macbookair on 15/04/16.
 */

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class SQLiteHelper extends SQLiteOpenHelper{
    //to_date('19960917','YYYYMMDD')
    private String getDateTime(int año,int mes,int dia,int hora,int minuto,int segundo) {
        Calendar newDate = Calendar.getInstance();
        newDate.set(año, mes, dia, hora, minuto, segundo);
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault());

        return dateFormat.format(newDate);
    }
    //Hotel
    private final String Hotel = "CREATE TABLE Hotel ("+
            "idHotel INTEGER PRIMARY KEY AUTOINCREMENT, "+
            "NombreH TEXT, DescripcionH TEXT, HorarioH TEXT, " +
            "TelefonoH TEXT, PrecioH DOUBLE, DireccionH TEXT , " +
            "LatitudH DOUBLE , LongitudH DOUBLE , Categoria_idCategoriaR INTEGER)";
    private final String reg1 = "INSERT INTO Hotel (NombreH,DescripcionH,HorarioH,TelefonoH,PrecioH,DireccionH,LatitudH,LongitudH,Categoria_idCategoriaR)" +
            "VALUES ('El Sueño Hotel','Este mágico hotel, ha sido instalado en una vieja casona del s. XVIII remodelada. " +
            "Conserva las características barrocas típicas con elementos contemporáneos y una decoración minimalista.','Todo el dia','232-6489'," +
            "2950,'9 Oriente No. 12, Centro Histórico, Puebla, Puebla" +
            " En el centro histórico, a 2 cuadras de la Catedral.',19.041017 ,-98.199479,8)";
    private final String reg2 = "INSERT INTO Hotel (NombreH,DescripcionH,HorarioH,TelefonoH,PrecioH,DireccionH,LatitudH,LongitudH,Categoria_idCategoriaR)" +
            "VALUES ('Hotel Palacio San Leonardo','Es un escaparate de estilo francés que se combina con la provincia mexicana y conserva el esplendor " +
            "de los. XIX y principios del XX. Ofrece todas las comodidades y una amplia gama de servicios.','Por noche','223-6600'," +
            "1430,'Av. 2 Oriente No. 211, Centro, Puebla, Puebla" +
            "En el corazón del Centro Histórico, entre 2 Norte y 4 Norte.',19.04382 ,-98.195697,9)";

    private final String reg3 = "INSERT INTO Hotel (NombreH,DescripcionH,HorarioH,TelefonoH,PrecioH,DireccionH,LatitudH,LongitudH,Categoria_idCategoriaR)" +
            "VALUES ('Hotel San Pedro','Edificio que data del año 1542, catalogado como Patrimonio Cultural de la Humanidad. " +
            "Habitaciones equipadas con pantalla LCD, caja de seguridad y chapas electrónicas.','Por noche','891-5700'," +
            "977,'Calle 2 Oriente No. 202, Centro Histórico, Puebla, Puebla " +
            "En el centro histórico, a 2 cuadras del Centro de Convenciones, a 15 minutos de la Central de Autobuses (CAPU).',19.044471,-98.196371,9)";

    //---Tabla Usuarios---//
    private final String Usuario = "CREATE TABLE Usuario ("+
            "idUsuario INTEGER PRIMARY KEY AUTOINCREMENT, "+
            "NUsuario TEXT, contrasena TEXT, correo TEXT)";
    private final String reg20 = "INSERT INTO Usuario (NUSuario,contrasena,correo) VALUES ('rlopez','123456','rlopez@hotmail.com')";
    private final String reg21 = "INSERT INTO Usuario (NUSuario,contrasena,correo) VALUES ('lperez','123456','lperez@hotmail.com')";
    //---Tabla Gustos---//
    private final String gustos = "CREATE TABLE Gustos ("+
            "idGustos INTEGER PRIMARY KEY AUTOINCREMENT, "+
            "Categoria_idCategoriaR INTEGER, Usuario_idUsuario INTEGER)";
    private final String reg22 = "INSERT INTO Gustos (Categoria_idCategoriaR,Usuario_idUsuario) VALUES (2,1) ";
    private final String reg23 = "INSERT INTO Gustos (Categoria_idCategoriaR,Usuario_idUsuario) VALUES (4,1) ";
    private final String reg24 = "INSERT INTO Gustos (Categoria_idCategoriaR,Usuario_idUsuario) VALUES (9,1) ";


    //---Tabla Categoria---//
    private final String categoria = "CREATE TABLE Categoria ("+
            "idCategoriaR INTEGER PRIMARY KEY AUTOINCREMENT, "+
            "NombreCatR TEXT)";
    private final String reg11 = "INSERT INTO Categoria (NombreCatR) VALUES ('Comida Rapida')";
    private final String reg12 = "INSERT INTO Categoria (NombreCatR) VALUES ('Comida Tipica')";
    private final String reg13 = "INSERT INTO Categoria (NombreCatR) VALUES ('Historicos')";
    private final String reg14 = "INSERT INTO Categoria (NombreCatR) VALUES ('Arte')";
    private final String reg15 = "INSERT INTO Categoria (NombreCatR) VALUES ('1')";
    private final String reg16 = "INSERT INTO Categoria (NombreCatR) VALUES ('2')";
    private final String reg17 = "INSERT INTO Categoria (NombreCatR) VALUES ('3')";
    private final String reg18 = "INSERT INTO Categoria (NombreCatR) VALUES ('5')";
    private final String reg19 = "INSERT INTO Categoria (NombreCatR) VALUES ('6')";
    //private final String reg1 = "INSERT INTO Categoria (NombreCatR) VALUES (Comida Tipica) ";
    //private final String reg2 = "INSERT INTO Categoria (NombreCatR) VALUES (Comida Rapida) ";
    //---Tabla Museo--//
    private final String Museo= "CREATE TABLE Museo ("+
            "idMuseo INTEGER PRIMARY KEY AUTOINCREMENT, "+
            "NombreM TEXT, DescripcionM TEXT, HorarioM TEXT, TelefonoM TEXT, PrecioM DOUBLE, " +
            "DireccionM TEXT , LatitudM DOUBLE , LongitudM DOUBLE , Categoria_idCategoriaR INTEGER)";
    public final String reg8 = "INSERT INTO Museo (NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM,Categoria_idCategoriaR) VALUES " +
            "('San Pedro museo de Arte','San Pedro Museo de Arte cuenta con más de 1,000 m2 de espacios de exhibición divididos " +
            "en 8 salas equipadas con la mejor infraestructura museográfica de la ciudad, apegada a los más altos estándares internacionales.'," +
            "'Martes a Domingo de 10:00 a 17:00 hrs.','(222) 246.6618',25,'4 Norte No. 203, Centro " +
            "PUEBLA, Puebla, 72000',19.043928,-98.195044,4)";
    public final String reg9 = "INSERT INTO Museo (NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM,Categoria_idCategoriaR) VALUES " +
            "('Museo José Luis Bello y González','El Museo Bello y González resguarda el acervo artístico más importante de Puebla y es uno de los más ricos ya que es una de las pocas casas-museo del país." +
            "El Museo José Luis Bello y González cuenta con: " +
            "3,028 obras de arte de América, Asia y Europa, algunas con 2,000 años de antigüedad.'," +
            "'Martes a Domingo de 10:00 a 17:00 hrs','(222) 232.9475',25,'3 Poniente No. 302, Centro PUEBLA, Puebla, 72000',19.044617,-98.200645,4)";
    public final String reg10 = "INSERT INTO Museo (NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM,Categoria_idCategoriaR) VALUES " +
            "('Museo Regional Casa de Alfeñique','Es el primer museo de la ciudad de Puebla, fundado en 1926. Resguarda una gran cantidad de objetos artísticos que denotan el desarrollo histórico y cultural." +
            "La Casa de Alfeñique es conocida con este nombre por su fachada ricamente decorada con yeserías ondulantes que parecen hechas de alfeñique (dulce español a base de pasta azucarada de almendras).'," +
            "'Martes a Domingo de 10:00 a 17:00 hrs', '(222) 232.0458',25,'4 Oriente No. 416 , Centro " +
            "PUEBLA, Puebla, 72000',19.043792,-98.193287,4)";
    //--Tabla Restaurante---//
    private final String Restaurante = "CREATE TABLE Restaurante ("+
            "idRestaurante INTEGER PRIMARY KEY AUTOINCREMENT, "+
            "NombreR TEXT, DescripcionR TEXT, TelefonoR TEXT, DireccionR TEXT , LatitudR DOUBLE , LongitudR DOUBLE , Categoria_idCategoriaR INTEGER)";
    private final String reg4 = "INSERT INTO Restaurante (NombreR,DescripcionR,TelefonoR,DireccionR,LatitudR,LongitudR,Categoria_idCategoriaR) VALUES" +
            "('Restaurante Casareyna','Opciones gastronómicas: Cena, desayuno, almuerzo, Desayuno-almuerzo, Abierto por la noche, Wi-Fi gratis, Bar completo, " +
            "Sillitas altas disponibles, asientos al aire libre, Reservaciones, Asiento, Sirve alcohol, Meseros, Acceso para silla de ruedas." +
            "Bueno para: Reuniones de negocios, Familias con niños, Ocasiones especiales, Grupos grandes, Comida local.','222 232 0032','2 Oriente 1007 | Centro Histórico, Puebla 72000, México " +
            "',19.041957,-98.191173,2)";
    private final String reg5 = "INSERT INTO Restaurante (NombreR,DescripcionR,TelefonoR,DireccionR,LatitudR,LongitudR,Categoria_idCategoriaR) VALUES" +
            "('Restaurante Moyuelo','Descripción: Cocina poblana contemporánea. Se recomienda reservar los días Viernes, Sábado y Domingo, tiempo máximo de espera de reserva 15min.'" +
            ",'+52 222 232 4270','Av. Juárez 1914-A1 | Junto a Sixt renta de autos, Puebla 72160, México',19.042376,-98.199712,2)";
    private final String reg6 = "INSERT INTO Restaurante (NombreR,DescripcionR,TelefonoR,DireccionR,LatitudR,LongitudR,Categoria_idCategoriaR) VALUES" +
            "('NAPOLI RISTORANTE PIZZERIA','Opciones gastronómicas: cena, Acepta Mastercard, Acepta Visa, Solo efectivo, Pagos digitales, Wi-Fi gratis, Bar completo, Sillitas " +
            "altas disponibles, asientos al aire libre, Estacionamiento disponible, Reservaciones, Asiento, Sirve alcohol, Estacionamiento en la calle, comida para llevar, Televisión, " +
            "Estacionamiento para clientes, Meseros, Acceso para silla de ruedas, Vino y cerveza','+52 222 621 9650','29 SUR 129 COL. LA PAZ, Puebla 72160, México'" +
            ",19.049765,-98.214134,1)";
    private final String reg7 = "INSERT INTO Restaurante (NombreR,DescripcionR,TelefonoR,DireccionR,LatitudR,LongitudR,Categoria_idCategoriaR) VALUES" +
            "('Restaurante El mural de los Poblanos','Opciones gastronómicas: desayuno, almuerzo, cena, Abierto por la noche, Wi-Fi gratis, Bar completo, Reservaciones, Asiento, Sirve alcohol, Meseros, Acceso para silla de ruedas \n" +
            "Bueno para: Comida local, Ocasiones especiales, Reuniones de negocios, Familias con niños','222-242-6696' ,'Calle 16 de Septiembre 506, Puebla 72000, México ',-19.25,33.2,2)";

    //---Agenda---//
    private final String Agenda = "CREATE TABLE Agenda ("+
            "idAgenda INTEGER PRIMARY KEY AUTOINCREMENT, "+
            "Usuario_idUsuario INTEGER)";

    //---Agenda has Restaurante
    private final String Agenda_has_Restaurante = "CREATE TABLE Agenda_has_Restaurante ("+
            "Agenda_idAgenda INTEGER, "+
            "Restaurante_idRestaurante INTEGER)";
    //---Agenda has Museo
    private final String Agenda_has_Museo = "CREATE TABLE Agenda_has_Museo ("+
            "Agenda_idAgenda INTEGER, "+
            "Restaurante_idMuseo INTEGER)";

    //---Agenda has Hotel
    private final String Agenda_has_hotel = "CREATE TABLE Agenda_has_Hotel ("+
            "Agenda_idAgenda INTEGER, "+
            "Restaurante_idHotel INTEGER)";

    private final String reg25 = "INSERT INTO Agenda (Usuario_idUsuario) VALUES (1)";
    private final String reg26= "INSERT INTO Agenda_has_Restaurante(Agenda_idAgenda,Restaurante_idRestaurante) VALUES (1,1)";
    private final String reg27= "INSERT INTO Agenda_has_Restaurante(Agenda_idAgenda,Restaurante_idRestaurante) VALUES (1,3)";
    private final String reg28= "INSERT INTO Agenda_has_Museo(Agenda_idAgenda,Restaurante_idMuseo) VALUES (1,1)";
    private final String reg29= "INSERT INTO Agenda_has_Museo(Agenda_idAgenda,Restaurante_idMuseo) VALUES (1,2)";
    private final String reg30= "INSERT INTO Agenda_has_Museo(Agenda_idAgenda,Restaurante_idMuseo) VALUES (1,3)";
    private final String reg31= "INSERT INTO Agenda_has_hotel(Agenda_idAgenda,Restaurante_idHotel) VALUES (1,4)";

    /**
     * Constructor de clase
     * */
    public SQLiteHelper(Context context) {
        super( context, "diabetes", null, 1 );
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL( Hotel );
        db.execSQL( Museo );
        db.execSQL( Restaurante );
        db.execSQL( Usuario );
        db.execSQL( gustos );
        db.execSQL( categoria );
        db.execSQL( Agenda );
        db.execSQL( Agenda_has_hotel );
        db.execSQL( Agenda_has_Museo );
        db.execSQL( Agenda_has_Restaurante );
        db.execSQL( reg1 );
        db.execSQL( reg2 );
        db.execSQL( reg3 );
        db.execSQL( reg4 );
        db.execSQL( reg5 );
        db.execSQL( reg6 );
        db.execSQL( reg7 );
        db.execSQL( reg8 );
        db.execSQL( reg9 );
        db.execSQL( reg10 );
        db.execSQL( reg11 );
        db.execSQL( reg12 );
        db.execSQL( reg13 );
        db.execSQL( reg14 );
        db.execSQL( reg15 );
        db.execSQL( reg16 );
        db.execSQL( reg17 );
        db.execSQL( reg18 );
        db.execSQL( reg19 );
        db.execSQL( reg20 );
        db.execSQL( reg21 );
        db.execSQL( reg22 );
        db.execSQL( reg23 );
        db.execSQL( reg24 );
        db.execSQL( reg25 );
        db.execSQL( reg26 );
        db.execSQL( reg27 );
        db.execSQL( reg28 );
        db.execSQL( reg29 );
        db.execSQL( reg30 );
        db.execSQL( reg31 );

    }

    @Override
    public void onUpgrade( SQLiteDatabase db,  int oldVersion, int newVersion ) {
        if ( newVersion > oldVersion )
        {
            db.execSQL( "DROP TABLE IF EXISTS Hotel" );
            db.execSQL( "DROP TABLE IF EXISTS Usuario" );
            db.execSQL( "DROP TABLE IF EXISTS Museo" );
            db.execSQL( "DROP TABLE IF EXISTS Restaurante" );
            db.execSQL( Hotel );
            db.execSQL( Museo );
            db.execSQL( Restaurante );
            db.execSQL( Usuario );
            db.execSQL( gustos );
            db.execSQL( categoria );
            db.execSQL( Agenda );
            db.execSQL( Agenda_has_hotel );
            db.execSQL( Agenda_has_Museo );
            db.execSQL( Agenda_has_Restaurante );
            db.execSQL( reg1 );
            db.execSQL( reg2 );
            db.execSQL( reg3 );
            db.execSQL( reg4 );
            db.execSQL( reg5 );
            db.execSQL( reg6 );
            db.execSQL( reg7 );
            db.execSQL( reg8 );
            db.execSQL( reg9 );
            db.execSQL( reg10 );
            db.execSQL( reg11 );
            db.execSQL( reg12 );
            db.execSQL( reg13 );
            db.execSQL( reg14 );
            db.execSQL( reg15 );
            db.execSQL( reg16 );
            db.execSQL( reg17 );
            db.execSQL( reg18 );
            db.execSQL( reg19 );
            db.execSQL( reg20 );
            db.execSQL( reg21 );
            db.execSQL( reg22 );
            db.execSQL( reg23 );
            db.execSQL( reg24 );
            db.execSQL( reg25 );
            db.execSQL( reg26 );
            db.execSQL( reg27 );
            db.execSQL( reg28 );
            db.execSQL( reg29 );
            db.execSQL( reg30 );
            db.execSQL( reg31 );

        }
    }

}//SQLiteHelper:end