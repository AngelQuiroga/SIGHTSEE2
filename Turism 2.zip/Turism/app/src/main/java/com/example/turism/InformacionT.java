package com.example.turism;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;

public class InformacionT extends Activity {

    TextView nombre,categoria;
    String [] name;
    turismoDB db;
    ArrayList<Museo> museo;
    ArrayList<Restauran> restaurante;
    ArrayList<Hotel> hotel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.informacion);
        Intent a1 = getIntent();
        name = a1.getStringArrayExtra(MyActivityG.ACT_INFO);
        db = new turismoDB(this);
        crea_acciones();

    }



    public void crea_acciones(){
        if(name[1].equalsIgnoreCase("Hotel")){crea_hotel(name[0]);}
        if(name[1].equalsIgnoreCase("Restaurante")){crea_restaurant(name[0]);}
        if(name[1].equalsIgnoreCase("Museo")){crea_museo(name[0]);}

    }

    public void crea_hotel(String v){
        db.openConnection();
        hotel = db.getHotel2(v);
        db.closeConnection();


        TableLayout tableLayout2 = (TableLayout)findViewById(R.id.tablageneral);
        tableLayout2.removeAllViewsInLayout();
        //tableLayout2.removeView(this);
        TableRow.LayoutParams tableRowParams = new TableRow.LayoutParams();
        tableRowParams.setMargins(2, 2, 2, 2);
        tableRowParams.weight = 1;
        //encabezado
        TableRow rowHead = new TableRow(this);
        rowHead.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        TextView tv41 = new TextView(this);
        tv41.setGravity(Gravity.CENTER);
        tv41.setTypeface(null, Typeface.BOLD);
        tv41.setTextSize(20);
        tv41.setPadding(6, 10, 6, 10);
        tv41.setText("IMAGEN");

        rowHead.addView(tv41, tableRowParams);

        tableLayout2.addView(rowHead);

        //
        TableRow rowHead1 = new TableRow(this);
        rowHead1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        TextView tv4 = new TextView(this);
        tv4.setGravity(Gravity.CENTER);
        tv4.setTypeface(null, Typeface.BOLD);
        tv4.setTextSize(20);
        tv4.setPadding(6, 10, 6, 10);
        tv4.setText(hotel.get(0).getNombre());

        rowHead1.addView(tv4, tableRowParams);

        tableLayout2.addView(rowHead1);

        TableRow rowHead2 = new TableRow(this);
        rowHead1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        TextView tv42 = new TextView(this);
        tv42.setGravity(Gravity.CENTER);
        tv42.setTypeface(null, Typeface.BOLD);
        tv42.setTextSize(20);
        tv42.setPadding(6, 10, 6, 10);
        tv42.setText(hotel.get(0).getDescripcion());

        rowHead2.addView(tv42, tableRowParams);

        tableLayout2.addView(rowHead2);


        TableRow rowHead3 = new TableRow(this);
        rowHead3.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        TextView tv43 = new TextView(this);
        tv43.setGravity(Gravity.CENTER);
        tv43.setTypeface(null, Typeface.BOLD);
        tv43.setTextSize(20);
        tv43.setPadding(6, 10, 6, 10);
        tv43.setText(hotel.get(0).getDireccion());

        rowHead3.addView(tv43, tableRowParams);

        tableLayout2.addView(rowHead3);

        TableRow rowHead4 = new TableRow(this);
        rowHead1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        TextView tv44 = new TextView(this);
        tv44.setGravity(Gravity.CENTER);
        tv44.setTypeface(null, Typeface.BOLD);
        tv44.setTextSize(20);
        tv44.setPadding(6, 10, 6, 10);
        tv44.setText(hotel.get(0).getHorario());

        rowHead4.addView(tv44, tableRowParams);

        tableLayout2.addView(rowHead4);

    }

    //mi tabla

    public void crea_restaurant(String v){
        db.openConnection();
        restaurante = db.getRestaurante2(v);
        db.closeConnection();


        TableLayout tableLayout2 = (TableLayout)findViewById(R.id.tablageneral);
        tableLayout2.removeAllViewsInLayout();
        //tableLayout2.removeView(this);
        TableRow.LayoutParams tableRowParams = new TableRow.LayoutParams();
        tableRowParams.setMargins(2, 2, 2, 2);
        tableRowParams.weight = 1;
        //encabezado
        TableRow rowHead = new TableRow(this);
        rowHead.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        TextView tv41 = new TextView(this);
        tv41.setGravity(Gravity.CENTER);
        tv41.setTypeface(null, Typeface.BOLD);
        tv41.setTextSize(20);
        tv41.setPadding(6, 10, 6, 10);
        tv41.setText("IMAGEN");

        rowHead.addView(tv41, tableRowParams);

        tableLayout2.addView(rowHead);

        //
        TableRow rowHead1 = new TableRow(this);
        rowHead1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        TextView tv4 = new TextView(this);
        tv4.setGravity(Gravity.CENTER);
        tv4.setTypeface(null, Typeface.BOLD);
        tv4.setTextSize(20);
        tv4.setPadding(6, 10, 6, 10);
        tv4.setText(restaurante.get(0).getNombre());

        rowHead1.addView(tv4, tableRowParams);

        tableLayout2.addView(rowHead1);

        TableRow rowHead2 = new TableRow(this);
        rowHead1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        TextView tv42 = new TextView(this);
        tv42.setGravity(Gravity.CENTER);
        tv42.setTypeface(null, Typeface.BOLD);
        tv42.setTextSize(20);
        tv42.setPadding(6, 10, 6, 10);
        tv42.setText(restaurante.get(0).getDescripcion());

        rowHead2.addView(tv42, tableRowParams);

        tableLayout2.addView(rowHead2);


        TableRow rowHead3 = new TableRow(this);
        rowHead3.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        TextView tv43 = new TextView(this);
        tv43.setGravity(Gravity.CENTER);
        tv43.setTypeface(null, Typeface.BOLD);
        tv43.setTextSize(20);
        tv43.setPadding(6, 10, 6, 10);
        tv43.setText(restaurante.get(0).getDireccion());

        rowHead3.addView(tv43, tableRowParams);

        tableLayout2.addView(rowHead3);

        TableRow rowHead4 = new TableRow(this);
        rowHead1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        TextView tv44 = new TextView(this);
        tv44.setGravity(Gravity.CENTER);
        tv44.setTypeface(null, Typeface.BOLD);
        tv44.setTextSize(20);
        tv44.setPadding(6, 10, 6, 10);
        tv44.setText(restaurante.get(0).getHorario());

        rowHead4.addView(tv44, tableRowParams);

        tableLayout2.addView(rowHead4);

    }

    //mi tabla

    public void crea_museo(String v){
        db.openConnection();
        museo = db.getMuseo2(v);
        db.closeConnection();


        TableLayout tableLayout2 = (TableLayout)findViewById(R.id.tablageneral);
        tableLayout2.removeAllViewsInLayout();
        //tableLayout2.removeView(this);
        TableRow.LayoutParams tableRowParams = new TableRow.LayoutParams();
        tableRowParams.setMargins(2, 2, 2, 2);
        tableRowParams.weight = 1;
        //encabezado
        TableRow rowHead = new TableRow(this);
        rowHead.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        TextView tv41 = new TextView(this);
        tv41.setGravity(Gravity.CENTER);
        tv41.setTypeface(null, Typeface.BOLD);
        tv41.setTextSize(20);
        tv41.setPadding(6, 10, 6, 10);
        tv41.setText("IMAGEN");

        rowHead.addView(tv41, tableRowParams);

        tableLayout2.addView(rowHead);

        //
        TableRow rowHead1 = new TableRow(this);
        rowHead1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        TextView tv4 = new TextView(this);
        tv4.setGravity(Gravity.CENTER);
        tv4.setTypeface(null, Typeface.BOLD);
        tv4.setTextSize(20);
        tv4.setPadding(6, 10, 6, 10);
        tv4.setText(museo.get(0).getNombre());

        rowHead1.addView(tv4, tableRowParams);

        tableLayout2.addView(rowHead1);

        TableRow rowHead2 = new TableRow(this);
        rowHead1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        TextView tv42 = new TextView(this);
        tv42.setGravity(Gravity.CENTER);
        tv42.setTypeface(null, Typeface.BOLD);
        tv42.setTextSize(20);
        tv42.setPadding(6, 10, 6, 10);
        tv42.setText(museo.get(0).getDescripcion());

        rowHead2.addView(tv42, tableRowParams);

        tableLayout2.addView(rowHead2);


        TableRow rowHead3 = new TableRow(this);
        rowHead3.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        TextView tv43 = new TextView(this);
        tv43.setGravity(Gravity.CENTER);
        tv43.setTypeface(null, Typeface.BOLD);
        tv43.setTextSize(20);
        tv43.setPadding(6, 10, 6, 10);
        tv43.setText(museo.get(0).getDireccion());

        rowHead3.addView(tv43, tableRowParams);

        tableLayout2.addView(rowHead3);

        TableRow rowHead4 = new TableRow(this);
        rowHead1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));


        TextView tv44 = new TextView(this);
        tv44.setGravity(Gravity.CENTER);
        tv44.setTypeface(null, Typeface.BOLD);
        tv44.setTextSize(20);
        tv44.setPadding(6, 10, 6, 10);
        tv44.setText(museo.get(0).getHorario());

        rowHead4.addView(tv44, tableRowParams);

        tableLayout2.addView(rowHead4);

    }

    //mi tabla
}