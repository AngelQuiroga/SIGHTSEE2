package com.example.turism;


/**
 * Created by macbookair on 16/04/16.
 */
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


public class Principal extends Activity {
    final static String ACT_INFO ="com.example.turism.INFORMACIONT";
    ListViewAdapter adapter;
    int categoria=0;
    String[] titulo = new String[]{
            "Busquedas",
            "Ubicacion",
            "Mi Agenda",
            "Busqueda por preferencia",
    };

    int[] imagenes = {
            R.drawable.icon01,
            R.drawable.icon02,
            R.drawable.agenda,
            R.drawable.icon02
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my2);
        Intent a1 = getIntent();
        categoria = a1.getIntExtra(Inicio.ACT_INFO, categoria);
        final ListView lista = (ListView) findViewById(R.id.listView1);
        adapter = new ListViewAdapter(this, titulo, imagenes);
        lista.setAdapter(adapter);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView adapterView, View view, int i, long l) {
                if (titulo[i].equalsIgnoreCase("Busquedas")) {
                    Intent i1 = new Intent(Principal.this, Busquedas.class);
                    startActivity(i1);
                }
                if (titulo[i].equalsIgnoreCase("Ubicacion")) {
                    Intent i1 = new Intent(Principal.this, MapsActivity.class);
                    startActivity(i1);
                }
                if (titulo[i].equalsIgnoreCase("Mi Agenda")) {
                    Intent i1 = new Intent(Principal.this, MyActivityAG.class);
                    i1.putExtra(ACT_INFO,categoria); startActivity(i1);
                    startActivity(i1);
                }
                if(titulo[i].equalsIgnoreCase("Busqueda por preferencia")){
                    Intent i1 = new Intent(Principal.this,MyActivityG.class); i1.putExtra(ACT_INFO,categoria); startActivity(i1);}
                //Intent i1 = new Intent(MyActivity.this,InformacionT.class);
                // String []dates=new String[20];
                // dates[0]=nombre[i];
                // dates[1]="Hotel";
                // i1.putExtra(ACT_INFO,dates);
                // startActivity(i1);
               // Toast.makeText(getApplicationContext(), "presiono " + i, Toast.LENGTH_SHORT).show();
            }
        });

        lista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView adapterView, View view, int i, long l) {
            //    Toast.makeText(getApplicationContext(), "presiono LARGO " + i, Toast.LENGTH_SHORT).show();
                return false;
            }
        });

    }
}