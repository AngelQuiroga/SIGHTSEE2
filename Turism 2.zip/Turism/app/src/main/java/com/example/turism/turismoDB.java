package com.example.turism;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Vector;

/**
 * Created by Sergio on 15/04/2016.
 */
public class turismoDB{



    private SQLiteHelper sqliteHelper;
    private SQLiteDatabase db;
    public turismoDB(Context context)
    {
        sqliteHelper = new SQLiteHelper( context );
    }

    public void openConnection(){
        db = sqliteHelper.getWritableDatabase();
    }

    public void closeConnection()
    {
        sqliteHelper.close();
    }


    //Métodos de Almacenar
    /*
    public void guardarPuntuacion(String nombre, String apllP, String apllM, String direc, String genero, String edad,String peso,String padecimiento,String medicamento, String usuario,String contraseña) {
        SQLiteDatabase db = getWritableDatabase();
        //db.execSQL("DELETE FROM datosPac");
        db.execSQL("INSERT INTO datosPac VALUES ( 1, '" + nombre + "', '" + apllP + "', '" + apllM + "', '" + direc + "', '" + genero + "', '" + edad + "', '" + peso + "', '" + padecimiento + "', '" + medicamento + "', '" + usuario + "', '" + contraseña + "')");
        db.close();
    }*/

    //Crear Usuario
    public void IngUsu(String nombreUs, String contr, String corr, String[] gustoU) {
        int idUs=0;
        //db.execSQL("DELETE FROM datosPac");
        //db.execSQL("INSERT INTO datosPac VALUES ( 1, '"+nombre+"', '"+apllP+"', '"+apllM+"', '"+direc+"', '"+genero+"', '"+edad+"', '"+peso+"', '"+padecimiento+"', '"+medicamento+"', '"+usuario+"', '"+contraseña+"')");

        db.execSQL("INSERT INTO Usuario (NUsuario,contrasena,correo) VALUES ('"+nombreUs+"','"+contr+"','"+corr+"') ");

        Vector result = new Vector();
        for(int j=0; j<gustoU.length;j++) {
            Cursor cursor = db.rawQuery("SELECT idCategoriaR FROM Categoria where NombreCatR='gustoU[j]'", null);//Obtiene el idCategoria segun el gusto [j]
            Cursor cursor2 = db.rawQuery("SELECT idUsuario FROM Usuario where NUsuario='nombreUs' and contrasena='contr'", null);//Obtiene el idUsuario

            if (cursor2.moveToFirst()) {
                do {

                    idUs = cursor2.getInt(0);
                } while (cursor2.moveToNext());
            }
            int idCat=0;
            if (cursor.moveToFirst()) {
                //Recorremos el cursor hasta que no haya más registros
                do {
                    //String codigo= c.getString(0);
                    //String nombre = c.getString(1);
                    idCat=cursor.getInt(0);
                } while (cursor.moveToNext());
            }

            db.execSQL("INSERT INTO Gustos (Categoria_idCategoriaR,Usuario_idUsuario) VALUES ('idCat','idUs') ");
            /*
            db.execSQL("INSERT INTO Museo (NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM,) VALUES ('nomM','descrM') ");
            db.execSQL("INSERT INTO Hotel (NombreH,DescripcionH,HorarioH,TelefonoH,PrecioH,DireccionH,LatitudH,LongitudH) VALUES ('nomH','descrH') ");
            db.execSQL("INSERT INTO Restaurante (NombreR,DescripcionR,HorarioR,TelefonoR,DireccionR,LatitudR,LongitudR) VALUES ('nomM','descrM') ");
            */
        }

        db.close();
      }

    //Buscar Usuario
    public int bucarUsuario(String nUsuario, String Contr) {
        int val=0;
        Vector result = new Vector();
        Cursor cursor = db.rawQuery("SELECT NUsuario,contrasena FROM Usuario where NUsuario='"+nUsuario+"' AND contrasena='"+Contr+"'", null);
        if(cursor.moveToFirst()){
            do {
                val++;
            } while(cursor.moveToNext());
        }
        return val;
    }

    //Crear Agenda
    public void Crear_Agenda(DateFormat fecha, int idUs) {

        db.execSQL("INSERT INTO Agenda (Usuario_idUsuario,Fecha) VALUES ('idUs','fecha') ");
        db.close();
    }
    //Insertar Lugar en Agenda

    /*
    public Vector listaPuntuaciones(int cantidad) {
        Vector result = new Vector();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " +
                "datosPac ORDER BY _id DESC ", null);
        while (cursor.moveToFirst()){
            result.add(cursor.getInt(0)+" " +cursor.getString(1)+" " +cursor.getString(2)+" " +cursor.getString(3)+" " +cursor.getString(4)+" " +cursor.getString(5)+" " +cursor.getString(6)+" " +cursor.getString(7)+" " +cursor.getString(8)+" " +cursor.getString(9)+" " +cursor.getString(10)+" " +cursor.getString(11));
        }
        cursor.close();
        db.close();
        return result;
    }
*/
    public void borrarTabla(String nombreT) {
        db.execSQL("DELETE FROM 'nombreT'");
        db.close();
    }


    public ArrayList<Hotel> getHotelCategoria(int idCategoria){
     //NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM
        // "idHotel INTEGER PRIMARY KEY AUTOINCREMENT, "+
        //"NombreH TEXT, DescripcionH TEXT, HorarioH TEXT, " +
               // "TelefonoH INTEGER, PrecioH DOUBLE, DireccionH TEXT , " +
                //"LatitudH DOUBLE , LongitudH DOUBLE , Categoria_idCategoriaR INTEGER)";
        ArrayList<Hotel> datosList = new ArrayList<Hotel>();
        Cursor cursor = db.rawQuery(" SELECT idHotel,NombreH,DescripcionH,HorarioH,TelefonoH,PrecioH,DireccionH,LatitudH,LongitudH FROM Hotel WHERE Categoria_idCategoriaR=" + idCategoria, null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            Hotel hotel = new Hotel();
            hotel.setId(cursor.getInt(cursor.getColumnIndexOrThrow("idHotel")));
            hotel.setNombre(cursor.getString(cursor.getColumnIndexOrThrow("NombreH")));
            hotel.setDescripcion(cursor.getString(cursor.getColumnIndexOrThrow("DescripcionH")));
            hotel.setHorario(cursor.getString(cursor.getColumnIndexOrThrow("HorarioH")));
            hotel.setTelefono(cursor.getString(cursor.getColumnIndexOrThrow("TelefonoH")));
            hotel.setPrecio(cursor.getDouble(cursor.getColumnIndexOrThrow("PrecioH")));
            hotel.setDireccion(cursor.getString(cursor.getColumnIndexOrThrow("DireccionH")));
            hotel.setLatitud(cursor.getInt(cursor.getColumnIndexOrThrow("LatitudH")));
            hotel.setLongitud(cursor.getInt(cursor.getColumnIndexOrThrow("LongitudH")));
            datosList.add(hotel);
        }
        return datosList;
    }

    public ArrayList<Hotel> getHotelId(int id){
        //NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM
        // "idHotel INTEGER PRIMARY KEY AUTOINCREMENT, "+
        //"NombreH TEXT, DescripcionH TEXT, HorarioH TEXT, " +
        // "TelefonoH INTEGER, PrecioH DOUBLE, DireccionH TEXT , " +
        //"LatitudH DOUBLE , LongitudH DOUBLE , Categoria_idCategoriaR INTEGER)";
        ArrayList<Hotel> datosList = new ArrayList<Hotel>();
        Cursor cursor = db.rawQuery(" SELECT idHotel,NombreH,DescripcionH,HorarioH,TelefonoH,PrecioH,DireccionH,LatitudH,LongitudH FROM Hotel WHERE idHotel=" + id, null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            Hotel hotel = new Hotel();
            hotel.setId(cursor.getInt(cursor.getColumnIndexOrThrow("idHotel")));
            hotel.setNombre(cursor.getString(cursor.getColumnIndexOrThrow("NombreH")));
            hotel.setDescripcion(cursor.getString(cursor.getColumnIndexOrThrow("DescripcionH")));
            hotel.setHorario(cursor.getString(cursor.getColumnIndexOrThrow("HorarioH")));
            hotel.setTelefono(cursor.getString(cursor.getColumnIndexOrThrow("TelefonoH")));
            hotel.setPrecio(cursor.getDouble(cursor.getColumnIndexOrThrow("PrecioH")));
            hotel.setDireccion(cursor.getString(cursor.getColumnIndexOrThrow("DireccionH")));
            hotel.setLatitud(cursor.getInt(cursor.getColumnIndexOrThrow("LatitudH")));
            hotel.setLongitud(cursor.getInt(cursor.getColumnIndexOrThrow("LongitudH")));
            datosList.add(hotel);
        }
        return datosList;
    }

    public ArrayList<Hotel> getHotel(){
        //NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM
        // "idHotel INTEGER PRIMARY KEY AUTOINCREMENT, "+
        //"NombreH TEXT, DescripcionH TEXT, HorarioH TEXT, " +
        // "TelefonoH INTEGER, PrecioH DOUBLE, DireccionH TEXT , " +
        //"LatitudH DOUBLE , LongitudH DOUBLE , Categoria_idCategoriaR INTEGER)";
        ArrayList<Hotel> datosList = new ArrayList<Hotel>();
        Cursor cursor = db.rawQuery(" SELECT idHotel,NombreH,DescripcionH,HorarioH,TelefonoH,PrecioH,DireccionH,LatitudH,LongitudH FROM Hotel WHERE 1", null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            Hotel hotel = new Hotel();
            hotel.setId(cursor.getInt(cursor.getColumnIndexOrThrow("idHotel")));
            hotel.setNombre(cursor.getString(cursor.getColumnIndexOrThrow("NombreH")));
            hotel.setDescripcion(cursor.getString(cursor.getColumnIndexOrThrow("DescripcionH")));
            hotel.setHorario(cursor.getString(cursor.getColumnIndexOrThrow("HorarioH")));
            hotel.setTelefono(cursor.getString(cursor.getColumnIndexOrThrow("TelefonoH")));
            hotel.setPrecio(cursor.getDouble(cursor.getColumnIndexOrThrow("PrecioH")));
            hotel.setDireccion(cursor.getString(cursor.getColumnIndexOrThrow("DireccionH")));
            hotel.setLatitud(cursor.getInt(cursor.getColumnIndexOrThrow("LatitudH")));
            hotel.setLongitud(cursor.getInt(cursor.getColumnIndexOrThrow("LongitudH")));
            datosList.add(hotel);
        }
        return datosList;
    }

    public ArrayList<Hotel> getHotel2(String variable){
        //NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM
        // "idHotel INTEGER PRIMARY KEY AUTOINCREMENT, "+
        //"NombreH TEXT, DescripcionH TEXT, HorarioH TEXT, " +
        // "TelefonoH INTEGER, PrecioH DOUBLE, DireccionH TEXT , " +
        //"LatitudH DOUBLE , LongitudH DOUBLE , Categoria_idCategoriaR INTEGER)";
        ArrayList<Hotel> datosList = new ArrayList<Hotel>();
        Cursor cursor = db.rawQuery(" SELECT idHotel,NombreH,DescripcionH,HorarioH,TelefonoH,PrecioH,DireccionH,LatitudH,LongitudH FROM Hotel WHERE NombreH='"+variable+"'", null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            Hotel hotel = new Hotel();
            hotel.setId(cursor.getInt(cursor.getColumnIndexOrThrow("idHotel")));
            hotel.setNombre(cursor.getString(cursor.getColumnIndexOrThrow("NombreH")));
            hotel.setDescripcion(cursor.getString(cursor.getColumnIndexOrThrow("DescripcionH")));
            hotel.setHorario(cursor.getString(cursor.getColumnIndexOrThrow("HorarioH")));
            hotel.setTelefono(cursor.getString(cursor.getColumnIndexOrThrow("TelefonoH")));
            hotel.setPrecio(cursor.getDouble(cursor.getColumnIndexOrThrow("PrecioH")));
            hotel.setDireccion(cursor.getString(cursor.getColumnIndexOrThrow("DireccionH")));
            hotel.setLatitud(cursor.getInt(cursor.getColumnIndexOrThrow("LatitudH")));
            hotel.setLongitud(cursor.getInt(cursor.getColumnIndexOrThrow("LongitudH")));
            datosList.add(hotel);
        }
        return datosList;
    }

    public int getAgendaID(int idUser){
        int agenda=0;
        //private final String Agenda = "CREATE TABLE Agenda ("+
          //      "idAgenda INTEGER PRIMARY KEY AUTOINCREMENT, "+
            //    "Usuario_idUsuario INTEGER)";
        Cursor cursor = db.rawQuery(" SELECT idAgenda FROM Agenda WHERE Usuario_idUsuario='"+idUser+"'", null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            agenda=cursor.getInt(0);
        }

        return agenda;
    }


    public  int [] getAgendaR(int idR){
        int a=0;
        //private final String Agenda = "CREATE TABLE Agenda ("+
        //      "idAgenda INTEGER PRIMARY KEY AUTOINCREMENT, "+
        //    "Usuario_idUsuario INTEGER)";
        Cursor cursor = db.rawQuery(" SELECT Agenda_idAgenda,Restaurante_idRestaurante FROM Agenda_has_Restaurante WHERE Agenda_idAgenda="+idR, null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){

            a++;
        }

        int agenda[];
        agenda = new int[a];
        a=0;
        Cursor cursor2 = db.rawQuery(" SELECT Agenda_idAgenda,Restaurante_idRestaurante FROM Agenda_has_Restaurante WHERE Agenda_idAgenda="+idR, null);

        cursor2.moveToFirst();
        for (cursor2.moveToFirst(); !cursor2.isAfterLast(); cursor2.moveToNext()){

            agenda[a]=cursor2.getInt(1);
              a++;
        }

        return agenda;
    }

    public int [] getAgendaH(int idH){
        int a=0;
        //private final String Agenda = "CREATE TABLE Agenda ("+
        //      "idAgenda INTEGER PRIMARY KEY AUTOINCREMENT, "+
        //    "Usuario_idUsuario INTEGER)";
        Cursor cursor = db.rawQuery(" SELECT Agenda_idAgenda,Restaurante_idHotel FROM Agenda_has_Hotel WHERE Agenda_idAgenda="+idH, null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){

            a++;
        }

        int agenda[];
        agenda = new int[a];
        a=0;
        Cursor cursor2 = db.rawQuery(" SELECT Agenda_idAgenda,Restaurante_idHotel FROM Agenda_has_Hotel WHERE Agenda_idAgenda="+idH, null);

        cursor2.moveToFirst();
        for (cursor2.moveToFirst(); !cursor2.isAfterLast(); cursor2.moveToNext()){

            agenda[a]=cursor2.getInt(1);
            a++;
        }

        return agenda;
    }

    public int [] getAgendaM(int idM){
        int a=0;
        //private final String Agenda = "CREATE TABLE Agenda ("+
        //      "idAgenda INTEGER PRIMARY KEY AUTOINCREMENT, "+
        //    "Usuario_idUsuario INTEGER)";
        Cursor cursor = db.rawQuery(" SELECT Agenda_idAgenda,Restaurante_idMuseo FROM Agenda_has_Museo WHERE Agenda_idAgenda="+idM, null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){

            a++;
        }

        int agenda[];
        agenda = new int[a];
        a=0;
        Cursor cursor2 = db.rawQuery(" SELECT Agenda_idAgenda,Restaurante_idMuseo FROM Agenda_has_Museo WHERE Agenda_idAgenda="+idM, null);

        cursor2.moveToFirst();
        for (cursor2.moveToFirst(); !cursor2.isAfterLast(); cursor2.moveToNext()){

            agenda[a]=cursor2.getInt(1);
              a++;
        }

        return agenda;
    }

    public int [] getGustosC(int idC){
        int a=0;
        //private final String Agenda = "CREATE TABLE Agenda ("+
        //      "idAgenda INTEGER PRIMARY KEY AUTOINCREMENT, "+
        //    "Usuario_idUsuario INTEGER)";
        //private final String reg22 = "INSERT INTO Gustos (Categoria_idCategoriaR,Usuario_idUsuario) VALUES (2,1) ";
        Cursor cursor = db.rawQuery(" SELECT Categoria_idCategoriaR,Usuario_idUsuario FROM Gustos WHERE Usuario_idUsuario="+idC, null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){

            a++;
        }

        int agenda[];
        agenda = new int[a];
        a=0;
        Cursor cursor2 = db.rawQuery(" SELECT Categoria_idCategoriaR,Usuario_idUsuario FROM Gustos WHERE Usuario_idUsuario="+idC, null);

        cursor2.moveToFirst();
        for (cursor2.moveToFirst(); !cursor2.isAfterLast(); cursor2.moveToNext()){

            agenda[a]=cursor2.getInt(0);
            a++;
        }

        return agenda;
    }

    public ArrayList<Museo> getMuseoCategoria(int idCategoria){
   //NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM
        ArrayList<Museo> datosList = new ArrayList<Museo>();
        Cursor cursor = db.rawQuery(" SELECT idMuseo,NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM FROM Museo WHERE Categoria_idCategoriaR=" + idCategoria, null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            Museo museo = new Museo();
            museo.setId(cursor.getInt(cursor.getColumnIndexOrThrow("idMuseo")));
            museo.setNombre(cursor.getString(cursor.getColumnIndexOrThrow("NombreM")));
            museo.setDescripcion(cursor.getString(cursor.getColumnIndexOrThrow("DescripcionM")));
            museo.setHorario(cursor.getString(cursor.getColumnIndexOrThrow("HorarioM")));
            museo.setTelefono(cursor.getString(cursor.getColumnIndexOrThrow("TelefonoM")));
            museo.setPrecio(cursor.getDouble(cursor.getColumnIndexOrThrow("PrecioM")));
            museo.setDireccion(cursor.getString(cursor.getColumnIndexOrThrow("DireccionM")));
            museo.setLatitud(cursor.getDouble(cursor.getColumnIndexOrThrow("LatitudM")));
            museo.setLongitud(cursor.getDouble(cursor.getColumnIndexOrThrow("LongitudM")));
            datosList.add(museo);
        }
        return datosList;
    }


    public ArrayList<Museo> getMuseoId(int id){
        //NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM
        ArrayList<Museo> datosList = new ArrayList<Museo>();
        Cursor cursor = db.rawQuery(" SELECT idMuseo,NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM FROM Museo WHERE idMuseo=" + id, null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            Museo museo = new Museo();
            museo.setId(cursor.getInt(cursor.getColumnIndexOrThrow("idMuseo")));
            museo.setNombre(cursor.getString(cursor.getColumnIndexOrThrow("NombreM")));
            museo.setDescripcion(cursor.getString(cursor.getColumnIndexOrThrow("DescripcionM")));
            museo.setHorario(cursor.getString(cursor.getColumnIndexOrThrow("HorarioM")));
            museo.setTelefono(cursor.getString(cursor.getColumnIndexOrThrow("TelefonoM")));
            museo.setPrecio(cursor.getDouble(cursor.getColumnIndexOrThrow("PrecioM")));
            museo.setDireccion(cursor.getString(cursor.getColumnIndexOrThrow("DireccionM")));
            museo.setLatitud(cursor.getInt(cursor.getColumnIndexOrThrow("LatitudM")));
            museo.setLongitud(cursor.getInt(cursor.getColumnIndexOrThrow("LongitudM")));
            datosList.add(museo);
        }
        return datosList;
    }


    public ArrayList<Museo> getMuseo(){
        //NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM
        ArrayList<Museo> datosList = new ArrayList<Museo>();
        Cursor cursor = db.rawQuery(" SELECT idMuseo,NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM FROM Museo WHERE 1", null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            Museo museo = new Museo();
            museo.setId(cursor.getInt(cursor.getColumnIndexOrThrow("idMuseo")));
            museo.setNombre(cursor.getString(cursor.getColumnIndexOrThrow("NombreM")));
            museo.setDescripcion(cursor.getString(cursor.getColumnIndexOrThrow("DescripcionM")));
            museo.setHorario(cursor.getString(cursor.getColumnIndexOrThrow("HorarioM")));
            museo.setTelefono(cursor.getString(cursor.getColumnIndexOrThrow("TelefonoM")));
            museo.setPrecio(cursor.getDouble(cursor.getColumnIndexOrThrow("PrecioM")));
            museo.setDireccion(cursor.getString(cursor.getColumnIndexOrThrow("DireccionM")));
            museo.setLatitud(cursor.getDouble(cursor.getColumnIndexOrThrow("LatitudM")));
            museo.setLongitud(cursor.getDouble(cursor.getColumnIndexOrThrow("LongitudM")));
            datosList.add(museo);
        }
        return datosList;
    }


    public ArrayList<Museo> getMuseo2(String variable){
        //NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM
        ArrayList<Museo> datosList = new ArrayList<Museo>();
        Cursor cursor = db.rawQuery(" SELECT idMuseo,NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM FROM Museo WHERE NombreM='"+variable+"'", null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            Museo museo = new Museo();
            museo.setId(cursor.getInt(cursor.getColumnIndexOrThrow("idMuseo")));
            museo.setNombre(cursor.getString(cursor.getColumnIndexOrThrow("NombreM")));
            museo.setDescripcion(cursor.getString(cursor.getColumnIndexOrThrow("DescripcionM")));
            museo.setHorario(cursor.getString(cursor.getColumnIndexOrThrow("HorarioM")));
            museo.setTelefono(cursor.getString(cursor.getColumnIndexOrThrow("TelefonoM")));
            museo.setPrecio(cursor.getDouble(cursor.getColumnIndexOrThrow("PrecioM")));
            museo.setDireccion(cursor.getString(cursor.getColumnIndexOrThrow("DireccionM")));
            museo.setLatitud(cursor.getDouble(cursor.getColumnIndexOrThrow("LatitudM")));
            museo.setLongitud(cursor.getDouble(cursor.getColumnIndexOrThrow("LongitudM")));
            datosList.add(museo);
        }
        return datosList;
    }


    public ArrayList<Restauran> getRestauranteCategoria(int idCategoria){
    //NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM
        ArrayList<Restauran> datosList = new ArrayList<Restauran>();
        Cursor cursor = db.rawQuery(" SELECT idRestaurante,NombreR,DescripcionR,TelefonoR,DireccionR,LatitudR,LongitudR FROM Restaurante WHERE Categoria_idCategoriaR=" + idCategoria, null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            Restauran restaurant = new Restauran();
            restaurant.setId(cursor.getInt(cursor.getColumnIndexOrThrow("idRestaurante")));
            restaurant.setNombre(cursor.getString(cursor.getColumnIndexOrThrow("NombreR")));
            restaurant.setDescripcion(cursor.getString(cursor.getColumnIndexOrThrow("DescripcionR")));
//            restaurant.setHorario(cursor.getString(cursor.getColumnIndexOrThrow("HorarioR")));
            restaurant.setTelefono(cursor.getString(cursor.getColumnIndexOrThrow("TelefonoR")));
            restaurant.setDireccion( cursor.getString(cursor.getColumnIndexOrThrow("DireccionR")) );
            restaurant.setLatitud( cursor.getInt(cursor.getColumnIndexOrThrow("LatitudR")) );
            restaurant.setLongitud( cursor.getInt(cursor.getColumnIndexOrThrow("LongitudR")) );
            datosList.add(restaurant);
        }
        return datosList;
    }

    public ArrayList<Restauran> getRestauranteId(int id){
        //NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM
        ArrayList<Restauran> datosList = new ArrayList<Restauran>();
        Cursor cursor = db.rawQuery(" SELECT idRestaurante,NombreR,DescripcionR,TelefonoR,DireccionR,LatitudR,LongitudR FROM Restaurante WHERE idRestaurante=" + id, null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            Restauran restaurant = new Restauran();
            restaurant.setId(cursor.getInt(cursor.getColumnIndexOrThrow("idRestaurante")));
            restaurant.setNombre(cursor.getString(cursor.getColumnIndexOrThrow("NombreR")));
            restaurant.setDescripcion(cursor.getString(cursor.getColumnIndexOrThrow("DescripcionR")));
//            restaurant.setHorario(cursor.getString(cursor.getColumnIndexOrThrow("HorarioR")));
            restaurant.setTelefono(cursor.getString(cursor.getColumnIndexOrThrow("TelefonoR")));
            restaurant.setDireccion( cursor.getString(cursor.getColumnIndexOrThrow("DireccionR")) );
            restaurant.setLatitud( cursor.getInt(cursor.getColumnIndexOrThrow("LatitudR")) );
            restaurant.setLongitud( cursor.getInt(cursor.getColumnIndexOrThrow("LongitudR")) );
            datosList.add(restaurant);
        }
        return datosList;
    }

    public ArrayList<Restauran> getRestaurante(){
        //NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM
        ArrayList<Restauran> datosList = new ArrayList<Restauran>();
        Cursor cursor = db.rawQuery(" SELECT idRestaurante,NombreR,DescripcionR,TelefonoR,DireccionR,LatitudR,LongitudR FROM Restaurante WHERE 1", null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            Restauran restaurant = new Restauran();
            restaurant.setId(cursor.getInt(cursor.getColumnIndexOrThrow("idRestaurante")));
            restaurant.setNombre(cursor.getString(cursor.getColumnIndexOrThrow("NombreR")));
            restaurant.setDescripcion(cursor.getString(cursor.getColumnIndexOrThrow("DescripcionR")));
//            restaurant.setHorario(cursor.getString(cursor.getColumnIndexOrThrow("HorarioR")));
            restaurant.setTelefono(cursor.getString(cursor.getColumnIndexOrThrow("TelefonoR")));
            restaurant.setDireccion( cursor.getString(cursor.getColumnIndexOrThrow("DireccionR")) );
            restaurant.setLatitud( cursor.getDouble(cursor.getColumnIndexOrThrow("LatitudR")) );
            restaurant.setLongitud( cursor.getDouble(cursor.getColumnIndexOrThrow("LongitudR")) );
            datosList.add(restaurant);
        }
        return datosList;
    }

    public ArrayList<Restauran> getRestaurante2(String variable){
        //NombreM,DescripcionM,HorarioM,TelefonoM,PrecioM,DireccionM,LatitudM,LongitudM
        ArrayList<Restauran> datosList = new ArrayList<Restauran>();
        Cursor cursor = db.rawQuery(" SELECT idRestaurante,NombreR,DescripcionR,TelefonoR,DireccionR,LatitudR,LongitudR FROM Restaurante WHERE NombreR='"+variable+"'", null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            Restauran restaurant = new Restauran();
            restaurant.setId(cursor.getInt(cursor.getColumnIndexOrThrow("idRestaurante")));
            restaurant.setNombre(cursor.getString(cursor.getColumnIndexOrThrow("NombreR")));
            restaurant.setDescripcion(cursor.getString(cursor.getColumnIndexOrThrow("DescripcionR")));
//            restaurant.setHorario(cursor.getString(cursor.getColumnIndexOrThrow("HorarioR")));
            restaurant.setTelefono(cursor.getString(cursor.getColumnIndexOrThrow("TelefonoR")));
            restaurant.setDireccion( cursor.getString(cursor.getColumnIndexOrThrow("DireccionR")) );
            restaurant.setLatitud( cursor.getDouble(cursor.getColumnIndexOrThrow("LatitudR")) );
            restaurant.setLongitud( cursor.getDouble(cursor.getColumnIndexOrThrow("LongitudR")) );
            datosList.add(restaurant);
        }
        return datosList;
    }

    public ArrayList<Usuario> getUsuario(String username,String contra){
       //"CREATE TABLE Usuario ("+"idUsuario INTEGER PRIMARY KEY AUTOINCREMENT, "+"NUsuario TEXT, contrasena TEXT, correo TEXT)";
        ArrayList<Usuario> user = new ArrayList<Usuario>();
        //idPaciente p_usuario, p_contra, p_correo, p_nombre, p_apellidop, p_apellidom, p_direccion, p_edad, p_peso, p_genero
        Cursor cursor = db.rawQuery(" SELECT idUsuario,NUsuario,contrasena,correo FROM Usuario WHERE NUsuario='"+username+"' AND contrasena='"+contra+"'", null);
        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            Usuario usuario = new Usuario();
            usuario.setId( cursor.getInt(cursor.getColumnIndexOrThrow("idUsuario")) );
            usuario.setUsuario( cursor.getString(cursor.getColumnIndexOrThrow("NUsuario")) );
            usuario.setContraseña(cursor.getString(cursor.getColumnIndexOrThrow("contrasena")));
            usuario.setCorreo(cursor.getString(cursor.getColumnIndexOrThrow("correo")));
            user.add(usuario);
        }
        return user;
    }
}

/*
public class DB {


//Paciente

    public ArrayList<Paciente> getPaciente(){
        //  Cursor cursor = db.rawQuery(" SELECT p_usuario, p_contra, p_correo, p_nombre, p_apellidop, p_apellidom, p_direccion, p_edad, p_peso, p_genero"+
        //        " FROM Paciente WHERE idPaciente=" + idP + "", null);

        ArrayList<Paciente> pacienteList = new ArrayList<Paciente>();
        //idPaciente p_usuario, p_contra, p_correo, p_nombre, p_apellidop, p_apellidom, p_direccion, p_edad, p_peso, p_genero
        Cursor cursor = db.query( "Paciente" ,
                new String[]{"idPaciente","p_usuario","p_contra","p_correo","p_nombre","p_apellidop","p_apellidom","p_direccion","p_edad","p_peso","p_genero"} , //columns
                null, //clausula where
                null, //The values for the WHERE clause
                null, // don't group the rows
                null, //don't filter by row groups
                null //The sort order
        );
        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            Paciente Paciente = new Paciente();
            Paciente.setId( cursor.getInt(cursor.getColumnIndexOrThrow("idPaciente")) );
            Paciente.setUsuario( cursor.getString(cursor.getColumnIndexOrThrow("p_usuario")) );
            Paciente.setContra( cursor.getString(cursor.getColumnIndexOrThrow("p_contra")) );
            Paciente.setCorreo( cursor.getString(cursor.getColumnIndexOrThrow("p_correo")) );
            Paciente.setNombre( cursor.getString(cursor.getColumnIndexOrThrow("p_nombre")) );
            Paciente.setApellidop( cursor.getString(cursor.getColumnIndexOrThrow("p_apellidop")) );
            Paciente.setApellidom(cursor.getString(cursor.getColumnIndexOrThrow("p_apellidom")));
            Paciente.setDireccion( cursor.getString(cursor.getColumnIndexOrThrow("p_direccion")) );
            Paciente.setEdad( cursor.getInt(cursor.getColumnIndexOrThrow("p_edad")) );
            Paciente.setPeso( cursor.getDouble(cursor.getColumnIndexOrThrow("p_peso")) );
            Paciente.setGenero( cursor.getString(cursor.getColumnIndexOrThrow("p_genero")) );
            pacienteList.add(Paciente);
        }
        return pacienteList;
    }

    public long setPaciente(String user, String contra,String email,String name,String ap,String am,String dir
            ,int edad, double peso, String gen) throws Exception{
        ContentValues ins= new ContentValues();
        ins.put("p_usuario",user);
        ins.put("p_contra",contra);
        ins.put("p_correo", email);

        ins.put("p_nombre",name);
        ins.put("p_apellidop",ap);
        ins.put("p_apellidom", am);
        ins.put("p_direccion",dir);
        ins.put("p_genero",gen);
        ins.put("p_edad",edad);
        ins.put("p_peso",peso);
        return db.insert("Paciente",null,ins);

    }

    //Medico

    public ArrayList<Medico> getMedico(){

        ArrayList<Medico> medicoList = new ArrayList<Medico>();
        ////id, m_nombre, m_apellidop, m_apellidom, m_direccion, m_telefono, m_celular, m_email
        Cursor cursor = db.query( "Medico" ,
                new String[]{"idMedico","m_usuario","m_contra","m_nombre","m_apellidop","m_apellidom","m_direccion","m_telefono","m_celular","m_email"} , //columns
                null, //clausula where
                null, //The values for the WHERE clause
                null, // don't group the rows
                null, //don't filter by row groups
                null //The sort order
        );
        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            Medico Medico = new Medico();
            Medico.setId( cursor.getInt(cursor.getColumnIndexOrThrow("idMedico")) );
            Medico.setUsuario( cursor.getString(cursor.getColumnIndexOrThrow("m_usuario")) );
            Medico.setContra( cursor.getString(cursor.getColumnIndexOrThrow("m_contra")) );
            Medico.setNombre( cursor.getString(cursor.getColumnIndexOrThrow("m_nombre")) );
            Medico.setApellidop( cursor.getString(cursor.getColumnIndexOrThrow("m_apellidop")) );
            Medico.setApellidom( cursor.getString(cursor.getColumnIndexOrThrow("m_apellidom")) );
            Medico.setDireccion( cursor.getString(cursor.getColumnIndexOrThrow("m_direccion")) );
            Medico.setTelefono( cursor.getString(cursor.getColumnIndexOrThrow("p_telefono")) );
            Medico.setCelular( cursor.getString(cursor.getColumnIndexOrThrow("p_celular")) );
            Medico.setCorreo( cursor.getString(cursor.getColumnIndexOrThrow("p_email")) );
            medicoList.add(Medico);
        }
        return medicoList;
    }

    public long setMedico(String user, String contra,String name, String ap, String am,String dir, String tel,String cel, String email) throws Exception{
        ContentValues ins= new ContentValues();
        ins.put("m_usuario",user);
        ins.put("m_contra",contra);
        ins.put("m_nombre",name);
        ins.put("m_apellidop",ap);
        ins.put("m_apellidom", am);
        ins.put("m_direccion",dir);
        ins.put("m_telefono",tel);
        ins.put("m_celular",cel);
        ins.put("m_correo", email);
        return db.insert("Medico",null,ins);

    }

    //Datos
    public ArrayList<Datos> getDatos(int idP){

        ArrayList<Datos> datosList = new ArrayList<Datos>();
        Cursor cursor = db.rawQuery(" SELECT idDatos,idPaciente,nivelGlucosa,insulina,tipoinsulina,tipomedicamento,dia,mes,año FROM Datos WHERE idPaciente=" + idP+" AND mes=04 ORDER BY dia ASC", null);

        cursor.moveToFirst();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            Datos Datos = new Datos();
            Datos.setId( cursor.getInt(cursor.getColumnIndexOrThrow("idDatos")) );
            Datos.setIdPac(cursor.getInt(cursor.getColumnIndexOrThrow("idPaciente")));
            Datos.setNivelGlucosa(cursor.getDouble(cursor.getColumnIndexOrThrow("nivelGlucosa")));
            Datos.setInsulina(cursor.getInt(cursor.getColumnIndexOrThrow("insulina")));
            Datos.setTipoInsulina(cursor.getString(cursor.getColumnIndexOrThrow("tipoinsulina")));
            Datos.setTipoMedicamento(cursor.getString(cursor.getColumnIndexOrThrow("tipomedicamento")));
            Datos.setDia(cursor.getInt(cursor.getColumnIndexOrThrow("dia")));
            Datos.setMes(cursor.getInt(cursor.getColumnIndexOrThrow("mes")));
            Datos.setAño(cursor.getInt(cursor.getColumnIndexOrThrow("año")));
            datosList.add(Datos);
        }
        return datosList;
    }

    public long setDatos(int idP, double level, int insu,String tipoi,String tipom,int dia,int mes,int año) throws Exception{
        ContentValues ins= new ContentValues();
        ins.put("idPaciente",idP);
        ins.put("nivelGlucosa",level);
        ins.put("insulina",insu);
        ins.put("tipoinsulina",tipoi);
        ins.put("tipomedicamento",tipom);
        ins.put("dia",dia);
        ins.put("mes",mes);
        ins.put("año",año);

        return db.insert("Datos",null,ins);
        //   db.execSQL("INSERT INTO Datos(idPaciente,nivelGlucosa,insulina,tipoinsulina,tipomedicamento,fecha) VALUES "+
        //         "("+idP+","+level+","+insu+","+tipoi+","+tipom+","+fecha+")");
    }

    public int verU(String user) throws Exception{
        int c1=0;
        Cursor c = db.rawQuery(" SELECT p_usuario FROM Paciente WHERE p_usuario='" + user + "' ", null);
        if (c.moveToFirst()) {
            //Recorremos el cursor hasta que no haya más registros
            do {
                c1++;
            } while(c.moveToNext());
        }
        return c1;
    }

    public String vernombreU(int id) throws Exception{
        String c1="";
        Cursor cursor = db.rawQuery(" SELECT p_usuario FROM Paciente WHERE idPaciente='" + id + "' ", null);
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            c1=cursor.getString(cursor.getColumnIndexOrThrow("p_usuario"));
        }
        return c1;
    }


    public int verC(String cont) throws Exception{
        int c1=0;
        Cursor c = db.rawQuery(" SELECT p_contra FROM Paciente WHERE p_contra='" + cont + "' ", null);
        if (c.moveToFirst()) {
            //Recorremos el cursor hasta que no haya más registros
            do {
                c1++;
            } while(c.moveToNext());
        }
        return c1;
    }

    public int verUC(String user,String cont) throws Exception{
        int c1=0;
        Cursor c = db.rawQuery(" SELECT p_usuario,p_contra FROM Paciente WHERE p_usuario='" + user + "' AND p_contra='" + cont + "' ", null);
        //Nos aseguramos de que existe al menos un registro
        if (c.moveToFirst()) {
            //Recorremos el cursor hasta que no haya más registros
            do {
                c1++;
            } while(c.moveToNext());
        }
        return c1;}

    public int getID(String user,String cont) throws Exception{
        int id=0;
        Cursor cursor = db.rawQuery(" SELECT idPaciente FROM Paciente WHERE p_usuario='" + user + "' AND p_contra='" + cont + "' ", null);
        //Nos aseguramos de que existe al menos un registro
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
            id=cursor.getInt(cursor.getColumnIndexOrThrow("idPaciente"));
        }

        return id;

    }

}
 */
