package com.example.turism;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Inicio extends Activity {
    final static String ACT_INFO ="com.example.turism.PRINCIPAL";

    turismoDB db;
    ArrayList<Usuario> us;
    TextView user,contra;
    int aa=0,id=0;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);
        //setSupportActionBar(toolbar);
        db = new turismoDB(this);
        user = (TextView) findViewById(R.id.logusuario);
        contra = (TextView) findViewById(R.id.logcontraseña);
        Button aceptar = (Button) findViewById(R.id.logok);
        Button registrar = (Button) findViewById(R.id.logregistro);
//logusuario, log ok

        aceptar.setOnClickListener(new View.OnClickListener() { //Aceptar
            public void onClick(View view) {

                db.openConnection();
                aa=db.bucarUsuario(user.getText().toString(),contra.getText().toString());
                us=db.getUsuario(user.getText().toString(), contra.getText().toString());
                db.closeConnection();
           //     Toast.makeText(Inicio.this, ""+aa, Toast.LENGTH_SHORT).show();
                if(aa>0) {
                    Intent nuevoform = new Intent(Inicio.this, Principal.class);
                    int manda;
                    manda = us.get(0).getId();
                    nuevoform.putExtra(ACT_INFO, manda);
                    startActivity(nuevoform);

                }
                else{
                    Toast.makeText(Inicio.this, "Error" + "\n", Toast.LENGTH_SHORT).show();

                }
            }
        });

        registrar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent nuevoform = new Intent(Inicio.this, registro.class);
                startActivity(nuevoform);
            }
        });


    }

}