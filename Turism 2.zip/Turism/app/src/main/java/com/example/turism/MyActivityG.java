package com.example.turism;

/**
 * Created by macbookair on 16/04/16.
 */

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class MyActivityG extends Activity {
    turismoDB db;
    ArrayList<Museo> museo;
    ArrayList<Restauran> restaurante;
    ArrayList<Hotel> hotel;
    int categorias[];
    ListViewAdapter adapter;
    String [] nombre;
    int [] imagen;
    int [] id;
    int total=0;
    int control=0;
    int iduser;
    String cual;
    final static String ACT_INFO ="com.example.turism.INFORMACIONT";


    String[] titulo = new String[]{
            "titulo1",
            "titulo2",
            "titulo3",
            "titulo4",
    };

    int[] imagenes = {
            R.drawable.icon01,
            R.drawable.icon02,
            R.drawable.icon01,
            R.drawable.icon02
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);
        Intent a1 = getIntent();

        iduser = a1.getIntExtra(Principal.ACT_INFO, iduser);
        db = new turismoDB(this);
        db.openConnection();
        categorias=db.getGustosC(iduser); //Se envia el id del usuario
        db.closeConnection();


        for(int i=0; i<categorias.length; i++) {
            db.openConnection();
            restaurante = db.getRestauranteCategoria(categorias[i]);
            db.closeConnection();
            total+=restaurante.size();
            }

        for(int i=0; i<categorias.length; i++) {
            db.openConnection();
            hotel = db.getHotelCategoria(categorias[i]);
            db.closeConnection();
            total+=hotel.size();
        }

        for(int i=0; i<categorias.length; i++) {
            db.openConnection();
            museo = db.getMuseoCategoria(categorias[i]);
            db.closeConnection();
            total+=museo.size();
        }


        nombre = new String[total];
        imagen = new int[total];
        id = new int[total];
        for(int i=0; i<categorias.length; i++) {
            db.openConnection();
            restaurante = db.getRestauranteCategoria(categorias[i]);
            db.closeConnection();

            for (int index = 0; index < restaurante.size(); index++)

            {
                nombre[control] = restaurante.get(index).getNombre();
                imagen[control] = R.drawable.restaurante;
                id[control] = 3;
                control++;

            }
        }


        for(int i=0; i<categorias.length; i++) {
            db.openConnection();
            museo = db.getMuseoCategoria(categorias[i]);
            db.closeConnection();

            for (int index = 0; index < museo.size(); index++)

            {
                nombre[control] = museo.get(index).getNombre();
                imagen[control] = R.drawable.museo;
                id[control] = 1;
                control++;

            }
        }

        for(int i=0; i<categorias.length; i++) {
            db.openConnection();
            hotel = db.getHotelCategoria(categorias[i]);
            db.closeConnection();

            for (int index = 0; index < hotel.size(); index++)

            {
                nombre[control] = hotel.get(index).getNombre();
                imagen[control] = R.drawable.hotel;
                id[control] = 2;
                control++;
            }

        }

        final ListView lista = (ListView) findViewById(R.id.listView1);
        adapter = new ListViewAdapter(this, nombre, imagen);
        lista.setAdapter(adapter);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView adapterView, View view, int i, long l) {
                if (id[i] == 1) {
                    Intent i1 = new Intent(MyActivityG.this,InformacionT.class);
                    String []dates=new String[20];
                    dates[0]=nombre[i];
                    dates[1]="Museo";
                    i1.putExtra(ACT_INFO,dates);
                    startActivity(i1);
                    Toast.makeText(getApplicationContext(), nombre[i]+" categoria: Museo", Toast.LENGTH_SHORT).show();
                }
                if (id[i] == 2) {
                    Intent i1 = new Intent(MyActivityG.this,InformacionT.class);
                    String []dates=new String[20];
                    dates[0]=nombre[i];
                    dates[1]="Hotel";
                    i1.putExtra(ACT_INFO,dates);
                    startActivity(i1);
                    Toast.makeText(getApplicationContext(), nombre[i]+" categoria: Hotel", Toast.LENGTH_SHORT).show();
                }
                if (id[i] == 3) {
                    Intent i1 = new Intent(MyActivityG.this,InformacionT.class);
                    String []dates=new String[20];
                    dates[0]=nombre[i];
                    dates[1]="Restaurante";
                    i1.putExtra(ACT_INFO,dates);
                    startActivity(i1);
                    Toast.makeText(getApplicationContext(), nombre[i]+" categoria: Restaurante", Toast.LENGTH_SHORT).show();
                }

            }
        });

        lista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView adapterView, View view, int i, long l) {
                Toast.makeText(getApplicationContext(), "presiono LARGO " + i, Toast.LENGTH_SHORT).show();
                return false;
            }
        });

    }
}
