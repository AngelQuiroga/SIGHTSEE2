package com.example.turism;

/**
 * Created by macbookair on 15/04/16.
 */
public class Museo {

    private int id;
    private String nombre;
    private String descripcion;
    private String horario;
    private String telefono;
    private double precio;
    private String direccion;
    private double latitud;
    private double longitud;

    public void setId(int id){
        this.id=id;
    }

    public int getId(){
        return id;
    }
    //

    public void setNombre(String nombre){
        this.nombre=nombre;
    }

    public String getNombre(){
        return nombre;
    }
    //
    public void setDescripcion(String descripcion){
        this.descripcion=descripcion;
    }

    public String getDescripcion(){
        return descripcion;
    }
    //
    public void setHorario(String horario){
        this.horario=horario;
    }

    public String getHorario(){
        return horario;
    }
    //
    public void setPrecio(double precio){
        this.precio=precio;
    }

    public double getPrecio(){
        return precio;
    }
//
    //

    public void setDireccion(String direccion){
        this.direccion=direccion;
    }

    public String getDireccion(){
        return direccion;
    }
    //
    public void setLatitud(double latitud){
        this.latitud=latitud;
    }

    public double getLatitud(){
        return latitud;
    }
    //

    public void setLongitud(double longitud){
        this.longitud=longitud;
    }

    public double getLongitud(){
        return longitud;
    }

    //
    public void setTelefono(String telefono){
        this.telefono=telefono;
    }

    public String getTelefono(){
        return telefono;
    }
}
