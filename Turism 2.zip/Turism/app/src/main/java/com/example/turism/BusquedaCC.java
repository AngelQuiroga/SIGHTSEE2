package com.example.turism;


/**
 * Created by macbookair on 16/04/16.
 */
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


public class BusquedaCC extends Activity {
    final static String ACT_INFO ="com.example.turism.PLATOS";
    ListViewAdapter adapter;
    String[] titulo = new String[]{
            "Comida Rapida",
            "Comida Tipica"
    };

    int[] imagenes = {
            R.drawable.icon01,
            R.drawable.icon02
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        final ListView lista = (ListView) findViewById(R.id.listView1);
        adapter = new ListViewAdapter(this, titulo, imagenes);
        lista.setAdapter(adapter);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView adapterView, View view, int i, long l) {
                //Intent i1 = new Intent(MyActivity.this,InformacionT.class);
                // String []dates=new String[20];
                // dates[0]=nombre[i];
                // dates[1]="Hotel";
                // i1.putExtra(ACT_INFO,dates);
                // startActivity(i1);
                if (titulo[i].equalsIgnoreCase("Comida Rapida")) {
                    Intent i1 = new Intent(BusquedaCC.this, Platos.class);
                    int manda;
                    manda=1;
                    i1.putExtra(ACT_INFO,manda);
                    startActivity(i1);
                }

                if (titulo[i].equalsIgnoreCase("Comida Tipica")) {
                    Intent i1 = new Intent(BusquedaCC.this, Platos.class);
                    int manda;
                    manda=2;
                    i1.putExtra(ACT_INFO,manda);
                    startActivity(i1);
                }

            }
        });

        lista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView adapterView, View view, int i, long l) {
                //Toast.makeText(getApplicationContext(), "presiono LARGO " + i, Toast.LENGTH_SHORT).show();
                return false;
            }
        });

    }
}