package com.example.turism;

/**
 * Created by macbookair on 15/04/16.
 */
public class Usuario {
    private String usuario;
    private String contraseña;
    private String correo;
    private int id;

    public void setId(int id){
        this.id=id;
    }

    public int getId(){
        return id;
    }

    public void setUsuario(String usuario){
        this.usuario=usuario;
    }

    public String getUsuario(){
        return usuario;
    }

    public void setContraseña(String contraseña){
        this.contraseña=contraseña;
    }

    public String getContraseña(){
        return contraseña;
    }

    public void setCorreo(String correo){
        this.correo=correo;
    }

    public String getCorreo(){
        return correo;
    }
}
