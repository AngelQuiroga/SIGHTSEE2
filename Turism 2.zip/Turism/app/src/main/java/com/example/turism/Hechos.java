package com.example.turism;

/**
 * Created by macbookair on 16/04/16.
 */
/**
 * Created by macbookair on 16/04/16.
 */
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


public class Hechos extends Activity {
    turismoDB db;
    ArrayList<Museo> museo;
    ListViewAdapter adapter;
    String [] nombre;
    int [] imagen;
    final static String ACT_INFO ="com.example.turism.INFORMACIONT";

    String[] titulo = new String[]{
            "titulo1",
            "titulo2",
            "titulo3",
            "titulo4",
    };

    int[] imagenes = {
            R.drawable.icon01,
            R.drawable.icon02,
            R.drawable.icon01,
            R.drawable.icon02
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);
        Intent a1 = getIntent();
        int categoria=0;
        categoria = a1.getIntExtra(BusquedaCM.ACT_INFO, categoria);
        db = new turismoDB(this);
        db.openConnection();
        museo = db.getMuseoCategoria(categoria);
        db.closeConnection();

        nombre = new String[museo.size()];
        imagen = new int[museo.size()];
        for(int index = 0; index<museo.size(); index++)
        {
            nombre[index]=museo.get(index).getNombre();
            imagen[index]=R.drawable.museo;
        }

        final ListView lista = (ListView) findViewById(R.id.listView1);
        adapter = new ListViewAdapter(this, nombre, imagen);
        lista.setAdapter(adapter);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView adapterView, View view, int i, long l) {
                /*Intent i1 = new Intent(Estrella.this,InformacionT.class);
                String []dates=new String[20];
                dates[0]=nombre[i];
                dates[1]="Hotel";
                i1.putExtra(ACT_INFO,dates);
                startActivity(i1);*/
                // Toast.makeText(getApplicationContext(), "presiono " + i, Toast.LENGTH_SHORT).show();
            }
        });

        lista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView adapterView, View view, int i, long l) {
                Toast.makeText(getApplicationContext(), "presiono LARGO " + i, Toast.LENGTH_SHORT).show();
                return false;
            }
        });

    }
}