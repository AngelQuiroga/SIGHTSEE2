package com.example.turism;

/**
 * Created by macbookair on 16/04/16.
 */
/**
 * Created by macbookair on 16/04/16.
 */
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


public class MyActivityM extends Activity {
    turismoDB db;
    ArrayList<Museo> museos;
    ListViewAdapter adapter;
    String [] nombre;
    int [] imagen;
    final static String ACT_INFO ="com.example.turism.INFORMACIONT";

    String[] titulo = new String[]{
            "titulo1",
            "titulo2",
            "titulo3",
            "titulo4",
    };

    int[] imagenes = {
            R.drawable.icon01,
            R.drawable.icon02,
            R.drawable.icon01,
            R.drawable.icon02
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);
        db = new turismoDB(this);
        db.openConnection();
        museos = db.getMuseo();
        db.closeConnection();
        nombre = new String[museos.size()];
        imagen = new int[museos.size()];
        for(int index = 0; index<museos.size(); index++)
        {
            nombre[index]=museos.get(index).getNombre();
            imagen[index]=R.drawable.museo;
        }

        final ListView lista = (ListView) findViewById(R.id.listView1);
        adapter = new ListViewAdapter(this, nombre, imagen);
        lista.setAdapter(adapter);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView adapterView, View view, int i, long l) {
                Intent i1 = new Intent(MyActivityM.this,InformacionT.class);
                String []dates=new String[20];
                dates[0]=nombre[i];
                dates[1]="Museo";
                i1.putExtra(ACT_INFO,dates);
                startActivity(i1);
                Toast.makeText(getApplicationContext(), "presiono " + i, Toast.LENGTH_SHORT).show();
            }
        });

        lista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView adapterView, View view, int i, long l) {
                Toast.makeText(getApplicationContext(), "presiono LARGO " + i, Toast.LENGTH_SHORT).show();
                return false;
            }
        });

    }
}