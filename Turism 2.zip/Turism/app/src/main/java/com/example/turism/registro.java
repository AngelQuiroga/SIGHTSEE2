package com.example.turism;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

/**
 * Created by NÉSTOR on 15/04/2016.
 */
public class registro extends Activity {

    Intent intent=null,chooser=null;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.registro);

        Button registrar = (Button) findViewById(R.id.regok);

        registrar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                // String usu = tusuario.getText().toString();

               Toast.makeText(registro.this, "No implementado" + "\n", Toast.LENGTH_SHORT).show();

//                Intent nuevoform = new Intent(registro.this, Principal.class);
  //              startActivity(nuevoform);
            }
        });







    }
}

