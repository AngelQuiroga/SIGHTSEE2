package com.example.turism;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class BusquedaGM extends Activity {
    final static String ACT_INFO ="com.example.turism.INFORMACIONT";
    ListViewAdapter adapter;
    String[] titulo = new String[]{
            "Busqueda General",
            "Busqueda por Categoria"
    };

    int[] imagenes = {
            R.drawable.icon01,
            R.drawable.icon02
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        final ListView lista = (ListView) findViewById(R.id.listView1);
        adapter = new ListViewAdapter(this, titulo, imagenes);
        lista.setAdapter(adapter);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView adapterView, View view, int i, long l) {
                //Intent i1 = new Intent(MyActivity.this,InformacionT.class);
                // String []dates=new String[20];
                // dates[0]=nombre[i];
                // dates[1]="Hotel";
                // i1.putExtra(ACT_INFO,dates);
                // startActivity(i1);
                if (titulo[i].equalsIgnoreCase("Busqueda General")) {
                    Intent i1 = new Intent(BusquedaGM.this, MyActivityM.class);
                    startActivity(i1);
                }
                if (titulo[i].equalsIgnoreCase("Busqueda por Categoria")) {
                    Intent i1 = new Intent(BusquedaGM.this, BusquedaCM.class);
                    startActivity(i1);
                }
            }
        });

        lista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView adapterView, View view, int i, long l) {
                //Toast.makeText(getApplicationContext(), "presiono LARGO " + i, Toast.LENGTH_SHORT).show();
                return false;
            }
        });

    }
}